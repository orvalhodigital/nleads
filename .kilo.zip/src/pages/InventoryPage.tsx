
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Inventory from '../components/Inventory';
import { useData } from '../contexts/DataContext';

const InventoryPage: React.FC = () => {
    const navigate = useNavigate();
    const {
        vehicles, leads, profile,
        addVehicle, updateVehicle, deleteVehicle, handleSellVehicle, addLead,
        loadData
    } = useData();

    // The ViewLead function in Inventory redirects to "leads" view with a focused ID.
    // In new router, we should navigate to `/leads?focus=ID` or something.
    const handleViewLead = (leadId: string) => {
        // Simple navigation to leads page
        // To support focus, LeadsPage needs to read state/query param
        navigate('/leads', { state: { focusedLeadId: leadId } });
    };

    return (
        <Inventory
            vehicles={vehicles}
            onAddVehicle={addVehicle}
            onUpdateVehicle={updateVehicle}
            onDeleteVehicle={deleteVehicle}
            onSellVehicle={handleSellVehicle}
            onAddLead={addLead}
            onViewLead={handleViewLead}
            leads={leads}
            userEmail={profile?.email}
            onDataChange={loadData}
        />
    );
};

export default InventoryPage;
